import os

program = "java -jar cloud.jar"
os.system(program)
